<p align="center">
  <img src="assets/terminal.gif" alt="Animated command prompt introducing Teresa, full-stack development and cybersecurity" width="860">
</p>

<h1 align="center">Hi there 👋 I'm Teresa</h1>
<h3 align="center">Full-Stack & Backend Developer | Application Security & Cybersecurity</h3>

<p align="center">
  📍 Tenerife, Canary Islands · Building applications and learning how to secure them
</p>

<p align="center">
  <a href="https://tere2087.github.io/"><img src="https://img.shields.io/badge/Portfolio-Visit-111827?style=for-the-badge&logo=githubpages&logoColor=white" alt="Portfolio" /></a>
  <a href="mailto:tecaherdev@gmail.com"><img src="https://img.shields.io/badge/Email-Contact-146c43?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" /></a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Backend-PHP%20%26%20Laravel-0A66C2?style=flat" alt="Backend: PHP and Laravel" />
  <img src="https://img.shields.io/badge/Python-Development-3776AB?style=flat" alt="Python development" />
  <img src="https://img.shields.io/badge/Cybersecurity-Learning%20%26%20Labs-2ea44f?style=flat" alt="Cybersecurity learning" />
</p>

<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=21&pause=1200&color=25B56A&center=true&vCenter=true&width=720&lines=Full-Stack+%26+Backend+Developer;Application+Security+Enthusiast;Building+CyberKnife;Always+building%2C+testing+and+learning" alt="Typing introduction" />
</p>

---

## 👩‍💻 About Me

I'm a **full-stack / backend developer** with professional experience working on web applications, REST APIs and databases. My work involves building features, investigating bugs and improving existing systems.

Alongside software development, I'm pursuing a **Master's in Cybersecurity** and exploring how applications behave under security testing. I enjoy understanding not only how software is built, but also where it can fail — and how to make it more resilient.

- 💻 **Development:** PHP, Laravel, Symfony, Python, Angular, TypeScript and SQL
- 🔧 **Interests:** backend architecture, API integrations, debugging and automation
- 🛡️ **Security:** secure coding, web/API security, ethical hacking and hands-on labs
- 🌍 **Location:** Canary Islands, Spain

---

## 🔐 Featured Project — CyberKnife

**CyberKnife** is my **work-in-progress master's project**: a modular cybersecurity platform in Python, designed around controlled, authorized assessments and extensible tool integrations.

Its development focuses on a maintainable CLI, modular architecture, testing, automation and security workflows. I'm building it iteratively and documenting the decisions as the project evolves.

> 🚧 **In active development.** This is a learning and engineering project, not a finished commercial security product.

---

## 🛡️ Cybersecurity Path

- 🐉 **Kali Linux** for labs and authorized security exercises
- 🔎 Reconnaissance and network analysis using **Nmap** and **Gobuster**
- 🌐 Learning **OWASP Top 10**, web application security and REST API authorization
- 🧪 Hands-on labs, security research and reproducible experiments
- 🔐 Applying secure development principles to software projects

> Ethical hacking and testing **only in labs or with explicit authorization**.

---

## 🎓 Education & Experience

- 🎓 **Higher Technician in Multi-platform Application Development (DAM)** — completed
- 🎓 **Master's in Cybersecurity** — in progress (expected 2027)
- 💼 **Professional experience:** Full-Stack / Backend Developer

---

## 🧠 What You'll Find on My GitHub

- 📂 Academic projects from DAM
- 💻 Web and application development projects
- 🐍 Python utilities, experiments and automation
- 🔐 Cybersecurity notes, labs and security-oriented software
- 🧩 Personal projects exploring architecture, testing and maintainability

You can explore more work in my **[developer portfolio](https://tere2087.github.io/)**.

---

## 💻 Languages & Frameworks

<p align="left">
  <img src="https://www.vectorlogo.zone/logos/java/java-vertical.svg" width="48" alt="Java"/>
  <img src="https://www.vectorlogo.zone/logos/python/python-icon.svg" width="48" alt="Python"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" width="48" alt="PHP"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg" width="48" alt="HTML5"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg" width="48" alt="CSS3"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" width="48" alt="JavaScript"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg" width="48" alt="React"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/laravel/laravel-original.svg" width="48" alt="Laravel"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/angular/angular-original.svg" width="48" alt="Angular"/>
</p>

---

## 🗄️ Databases

<p align="left">
  <img src="https://www.vectorlogo.zone/logos/postgresql/postgresql-icon.svg" width="48" alt="PostgreSQL"/>
  <img src="https://www.vectorlogo.zone/logos/mysql/mysql-icon.svg" width="48" alt="MySQL"/>
  <img src="https://www.vectorlogo.zone/logos/mariadb/mariadb-icon.svg" width="48" alt="MariaDB"/>
</p>

Topics I work with or study include SQL queries, roles and privileges, access control, data exposure risks, SQL injection and database security fundamentals.

---

## 🧰 Tools & Technologies

<p align="left">
  <img src="https://www.kali.org/images/kali-dragon-icon.svg" width="48" alt="Kali Linux"/>
  <img src="https://www.vectorlogo.zone/logos/visualstudio_code/visualstudio_code-icon.svg" width="48" alt="VS Code"/>
  <img src="https://resources.jetbrains.com/storage/products/company/brand/logos/jb_square.svg" width="48" alt="JetBrains"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/git/git-original.svg" width="48" alt="Git"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/github/github-original.svg" width="48" alt="GitHub"/>
</p>

---

## 🖥️ Environment

<p align="left">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/windows8/windows8-original.svg" width="48" alt="Windows"/>
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" width="48" alt="Linux"/>
</p>

---

## 🎯 Current Focus

- Building practical tools and maintaining full-stack/backend applications
- Developing **CyberKnife** as an iterative cybersecurity engineering project
- Deepening my knowledge of web and API security
- Improving secure coding, automation and testing practices

---

## 📫 Contact

📧 **tecaherdev@gmail.com**  
🌐 **[Portfolio](https://tere2087.github.io/)**

---

<p align="center">
  <i>"Understanding how systems break is the first step to building them better."</i>
</p>
